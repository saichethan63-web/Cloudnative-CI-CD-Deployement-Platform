'use strict';

const request = require('supertest');
const { createApp } = require('../src/app');

const silent = { info() {}, error() {} };
let app;

beforeEach(() => {
  app = createApp({ logger: silent });
});

describe('operational endpoints', () => {
  test('GET /api/health returns ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });

  test('GET /api/ready flips to 503 during shutdown', async () => {
    expect((await request(app).get('/api/ready')).status).toBe(200);
    app.locals.ready = false;
    expect((await request(app).get('/api/ready')).status).toBe(503);
  });

  test('GET /metrics exposes Prometheus metrics including request counters', async () => {
    await request(app).get('/api/health');
    const res = await request(app).get('/metrics');
    expect(res.status).toBe(200);
    expect(res.text).toContain('http_requests_total{method="GET",route="/api/health",status_code="200"}');
    expect(res.text).toContain('http_request_duration_seconds_bucket');
    expect(res.text).toContain('process_cpu_user_seconds_total');
  });
});

describe('application endpoints', () => {
  test('GET /api/info returns build metadata', async () => {
    const res = await request(app).get('/api/info');
    expect(res.status).toBe(200);
    expect(res.body).toEqual(
      expect.objectContaining({ name: 'cloudnative-app', hostname: expect.any(String), environment: expect.any(String) })
    );
  });

  test('POST /api/items validates and stores items', async () => {
    const bad = await request(app).post('/api/items').send({ name: '   ' });
    expect(bad.status).toBe(400);

    const ok = await request(app).post('/api/items').send({ name: 'first' });
    expect(ok.status).toBe(201);
    expect(ok.body.name).toBe('first');

    const list = await request(app).get('/api/items');
    expect(list.body.count).toBe(1);
  });

  test('GET /api/simulate honours requested status and clamps delay', async () => {
    const res = await request(app).get('/api/simulate?status=503&delay=10');
    expect(res.status).toBe(503);
    expect(res.body.delay).toBe(10);
  });

  test('unknown API routes return JSON 404', async () => {
    const res = await request(app).get('/api/nope');
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('not found');
  });

  test('serves the web UI at /', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/html/);
  });

  test('sets security headers', async () => {
    const res = await request(app).get('/api/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });
});
