(() => {
  const $ = (id) => document.getElementById(id);
  let startedAt = null;

  function fmtDuration(totalSeconds) {
    const s = Math.max(0, Math.floor(totalSeconds));
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    const parts = [];
    if (d) parts.push(`${d}d`);
    if (d || h) parts.push(`${h}h`);
    parts.push(`${m}m`, `${s % 60}s`);
    return parts.join(' ');
  }

  async function loadInfo() {
    try {
      const info = await (await fetch('/api/info', { cache: 'no-store' })).json();
      $('container-id').textContent = info.hostname;
      $('m-env').textContent = info.environment;
      $('m-version').textContent = info.version;
      $('m-commit').textContent = info.commit.slice(0, 7);
      $('m-node').textContent = info.nodeVersion;
      startedAt = Date.now() - info.uptimeSeconds * 1000;
    } catch {
      $('container-id').textContent = 'unreachable';
    }
  }

  async function checkHealth() {
    const dot = $('status-dot');
    try {
      const res = await fetch('/api/health', { cache: 'no-store' });
      const up = res.ok;
      dot.className = `dot ${up ? 'up' : 'down'}`;
      $('status-text').textContent = up ? 'Healthy' : 'Unhealthy';
    } catch {
      dot.className = 'dot down';
      $('status-text').textContent = 'Unreachable';
    }
  }

  function addLog(text, bad) {
    const li = document.createElement('li');
    li.textContent = `${new Date().toLocaleTimeString()}  ${text}`;
    if (bad) li.className = 'bad';
    const log = $('log');
    log.prepend(li);
    while (log.children.length > 30) log.lastChild.remove();
  }

  const RUNS = {
    normal: { label: 'Normal traffic', count: 25, path: () => '/api/info' },
    slow: { label: 'Slow requests', count: 10, path: () => `/api/simulate?delay=${300 + Math.floor(Math.random() * 900)}` },
    errors: { label: 'Server errors', count: 10, path: () => '/api/simulate?status=500' },
  };

  async function run(kind, button) {
    const cfg = RUNS[kind];
    button.disabled = true;
    let ok = 0;
    let failed = 0;
    const t0 = performance.now();
    await Promise.all(
      Array.from({ length: cfg.count }, async () => {
        try {
          const res = await fetch(cfg.path(), { cache: 'no-store' });
          if (res.ok) ok += 1; else failed += 1;
        } catch {
          failed += 1;
        }
      })
    );
    const ms = Math.round(performance.now() - t0);
    addLog(`${cfg.label}: ${ok} succeeded, ${failed} failed in ${ms} ms`, failed > 0);
    button.disabled = false;
  }

  document.querySelectorAll('button[data-run]').forEach((btn) =>
    btn.addEventListener('click', () => run(btn.dataset.run, btn))
  );

  loadInfo();
  checkHealth();
  setInterval(checkHealth, 5000);
  setInterval(() => {
    if (startedAt) $('m-uptime').textContent = fmtDuration((Date.now() - startedAt) / 1000);
  }, 1000);
})();
