'use strict';

const os = require('os');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const config = require('./config');
const { createMetrics } = require('./metrics');

const MAX_ITEMS = 100;
const startedAt = Date.now();

function createApp({ logger = console } = {}) {
  const app = express();
  const metrics = createMetrics();
  const items = [];

  app.locals.ready = true;
  app.disable('x-powered-by');
  app.set('trust proxy', 1); // we always sit behind Nginx

  app.use(
    helmet({
      // The platform is served over plain HTTP until a TLS cert is attached.
      hsts: false,
      contentSecurityPolicy: {
        useDefaults: true,
        directives: { 'upgrade-insecure-requests': null },
      },
    })
  );
  app.use(metrics.middleware);
  app.use(express.json({ limit: '10kb' }));

  // Structured access log (skips noisy probes).
  app.use((req, res, next) => {
    const start = process.hrtime.bigint();
    res.once('close', () => {
      if (req.path === '/metrics' || req.path === '/api/health') return;
      logger.info(
        JSON.stringify({
          level: 'info',
          msg: 'request',
          method: req.method,
          path: req.path,
          status: res.statusCode,
          duration_ms: Number(process.hrtime.bigint() - start) / 1e6,
          request_id: req.get('x-request-id') || undefined,
        })
      );
    });
    next();
  });

  // ---- Operational endpoints -------------------------------------------
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', uptimeSeconds: Math.round(process.uptime()) });
  });

  app.get('/api/ready', (req, res) => {
    if (!req.app.locals.ready) return res.status(503).json({ status: 'shutting_down' });
    return res.json({ status: 'ready' });
  });

  app.get('/metrics', async (_req, res, next) => {
    try {
      res.set('Content-Type', metrics.register.contentType);
      res.end(await metrics.register.metrics());
    } catch (err) {
      next(err);
    }
  });

  // ---- Application endpoints -------------------------------------------
  app.get('/api/info', (_req, res) => {
    res.json({
      name: 'cloudnative-app',
      version: config.version,
      commit: config.commit,
      environment: config.env,
      hostname: os.hostname(),
      nodeVersion: process.version,
      startedAt: new Date(startedAt).toISOString(),
      uptimeSeconds: Math.round((Date.now() - startedAt) / 1000),
    });
  });

  app.get('/api/items', (_req, res) => {
    res.json({ count: items.length, items });
  });

  app.post('/api/items', (req, res) => {
    const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
    if (!name || name.length > 100) {
      return res.status(400).json({ error: 'name must be a non-empty string up to 100 characters' });
    }
    if (items.length >= MAX_ITEMS) {
      return res.status(409).json({ error: `item limit of ${MAX_ITEMS} reached` });
    }
    const item = { id: items.length + 1, name, createdAt: new Date().toISOString() };
    items.push(item);
    return res.status(201).json(item);
  });

  // Generates latency / errors on demand so dashboards and alerts can be demoed.
  app.get('/api/simulate', (req, res) => {
    const delay = Math.min(Math.max(parseInt(req.query.delay, 10) || 0, 0), 2000);
    const status = parseInt(req.query.status, 10);
    const code = status >= 200 && status <= 599 ? status : 200;
    setTimeout(() => res.status(code).json({ simulated: true, delay, status: code }), delay);
  });

  app.use(express.static(path.join(__dirname, 'public'), { maxAge: '5m' }));

  app.use('/api', (_req, res) => res.status(404).json({ error: 'not found' }));

  app.use((err, _req, res, _next) => {
    logger.error(JSON.stringify({ level: 'error', msg: err.message }));
    const status = err.status || err.statusCode || 500;
    res.status(status).json({ error: status === 500 ? 'internal server error' : err.message });
  });

  return app;
}

module.exports = { createApp };
