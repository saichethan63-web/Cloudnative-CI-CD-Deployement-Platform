'use strict';

// All runtime configuration comes from environment variables (12-factor).
module.exports = {
  env: process.env.APP_ENV || process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3000', 10),
  version: process.env.APP_VERSION || '1.0.0',
  commit: process.env.COMMIT_SHA || 'local',
};
