'use strict';

const client = require('prom-client');

/**
 * Builds an isolated Prometheus registry plus an Express middleware that
 * records request count, latency and in-flight gauge. A fresh registry per app
 * instance keeps tests independent of each other.
 */
function createMetrics() {
  const register = new client.Registry();
  client.collectDefaultMetrics({ register });

  const labelNames = ['method', 'route', 'status_code'];

  const requestsTotal = new client.Counter({
    name: 'http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames,
    registers: [register],
  });

  const requestDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'HTTP request latency in seconds',
    labelNames,
    buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
    registers: [register],
  });

  const inFlight = new client.Gauge({
    name: 'http_requests_in_flight',
    help: 'Number of HTTP requests currently being processed',
    registers: [register],
  });

  function middleware(req, res, next) {
    if (req.path === '/metrics') return next();

    const stopTimer = requestDuration.startTimer();
    inFlight.inc();

    res.once('close', () => {
      // Use the route pattern (not the raw URL) to keep label cardinality low.
      let route = 'static';
      if (req.route) route = `${req.baseUrl}${req.route.path}`;
      else if (res.statusCode === 404) route = 'unmatched';

      const labels = {
        method: req.method,
        route,
        status_code: String(res.statusCode),
      };
      requestsTotal.inc(labels);
      stopTimer(labels);
      inFlight.dec();
    });

    next();
  }

  return { register, middleware };
}

module.exports = { createMetrics };
