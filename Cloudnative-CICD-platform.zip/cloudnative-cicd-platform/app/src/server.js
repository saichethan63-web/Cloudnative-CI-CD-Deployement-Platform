'use strict';

const config = require('./config');
const { createApp } = require('./app');

const app = createApp();
const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(JSON.stringify({ level: 'info', msg: 'server started', port: config.port, env: config.env, commit: config.commit }));
});

// Must exceed Nginx's upstream keep-alive timeout to avoid sporadic 502s.
server.keepAliveTimeout = 65000;
server.headersTimeout = 66000;

function shutdown(signal) {
  console.log(JSON.stringify({ level: 'info', msg: 'shutting down', signal }));
  app.locals.ready = false;
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
