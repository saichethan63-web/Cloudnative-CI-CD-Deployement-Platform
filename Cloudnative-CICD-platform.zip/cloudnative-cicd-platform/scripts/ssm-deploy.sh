#!/usr/bin/env bash
# Runs the server-side deploy helper through AWS Systems Manager and waits for the result.
# Usage: INSTANCE_ID=i-xxxx scripts/ssm-deploy.sh <s3-bundle-key> <image-uri>
set -euo pipefail

BUNDLE_KEY="${1:?usage: ssm-deploy.sh <bundle-key> <image-uri>}"
IMAGE="${2:?usage: ssm-deploy.sh <bundle-key> <image-uri>}"
: "${INSTANCE_ID:?INSTANCE_ID must be set}"

PARAMS=$(jq -n --arg c "/usr/local/bin/platform-deploy ${BUNDLE_KEY} ${IMAGE}" \
  '{commands: [$c], executionTimeout: ["900"]}')

CMD_ID=$(aws ssm send-command \
  --instance-ids "$INSTANCE_ID" \
  --document-name AWS-RunShellScript \
  --comment "Deploy ${IMAGE##*:}" \
  --parameters "$PARAMS" \
  --query Command.CommandId --output text)
echo "SSM command: $CMD_ID"

STATUS="Pending"
for _ in $(seq 1 180); do
  sleep 5
  STATUS=$(aws ssm get-command-invocation --command-id "$CMD_ID" --instance-id "$INSTANCE_ID" \
    --query Status --output text 2>/dev/null || echo Pending)
  case "$STATUS" in Success | Failed | Cancelled | TimedOut) break ;; esac
done

echo "----- stdout -----"
aws ssm get-command-invocation --command-id "$CMD_ID" --instance-id "$INSTANCE_ID" \
  --query StandardOutputContent --output text || true
echo "----- stderr -----"
aws ssm get-command-invocation --command-id "$CMD_ID" --instance-id "$INSTANCE_ID" \
  --query StandardErrorContent --output text || true

echo "Final status: $STATUS"
[ "$STATUS" = "Success" ]
