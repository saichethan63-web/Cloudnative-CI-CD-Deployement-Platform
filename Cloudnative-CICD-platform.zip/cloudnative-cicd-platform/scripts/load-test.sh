#!/usr/bin/env bash
# Generates traffic so the Grafana dashboards have data.
# Usage: scripts/load-test.sh [base-url] [seconds]
set -euo pipefail
BASE="${1:-http://localhost:8080}"
DURATION="${2:-60}"
END=$((SECONDS + DURATION))
echo "Sending traffic to $BASE for ${DURATION}s (Ctrl+C to stop)"
while [ "$SECONDS" -lt "$END" ]; do
  curl -s -o /dev/null "$BASE/api/info" &
  curl -s -o /dev/null "$BASE/api/simulate?delay=$((RANDOM % 600))" &
  [ $((RANDOM % 10)) -eq 0 ] && curl -s -o /dev/null "$BASE/api/simulate?status=500" &
  sleep 0.2
done
wait
echo "Done."
