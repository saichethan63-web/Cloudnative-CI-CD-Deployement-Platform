#!/usr/bin/env bash
# Copies Terraform outputs into GitHub repository variables/secrets so the workflows work.
# Requires: gh (authenticated) and terraform, run from the repository root after `terraform apply`.
set -euo pipefail

TF="terraform -chdir=terraform output -raw"

gh variable set AWS_REGION      --body "$($TF aws_region)"
gh variable set ECR_REPOSITORY  --body "$($TF ecr_repository_name)"
gh variable set ARTIFACT_BUCKET --body "$($TF artifact_bucket)"
gh variable set INSTANCE_ID     --body "$($TF instance_id)"
gh variable set APP_URL         --body "$($TF app_url)"
gh secret set AWS_ROLE_ARN      --body "$($TF github_actions_role_arn)"

# The deploy job targets the "production" environment (add required reviewers in the UI if desired).
gh api -X PUT "repos/{owner}/{repo}/environments/production" >/dev/null

echo "GitHub configuration complete."
