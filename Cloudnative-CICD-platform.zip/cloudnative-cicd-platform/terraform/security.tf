resource "aws_security_group" "web" {
  name_prefix = "${local.name}-web-"
  description = "Web server: HTTP in, all traffic out"
  vpc_id      = aws_vpc.main.id

  tags = { Name = "${local.name}-web-sg" }

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_vpc_security_group_ingress_rule" "http" {
  for_each = toset(var.http_allowed_cidrs)

  security_group_id = aws_security_group.web.id
  description       = "HTTP (Nginx reverse proxy)"
  cidr_ipv4         = each.value
  from_port         = 80
  to_port           = 80
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_ingress_rule" "ssh" {
  for_each = toset(var.ssh_allowed_cidrs)

  security_group_id = aws_security_group.web.id
  description       = "SSH (restricted)"
  cidr_ipv4         = each.value
  from_port         = 22
  to_port           = 22
  ip_protocol       = "tcp"
}

resource "aws_vpc_security_group_egress_rule" "all" {
  security_group_id = aws_security_group.web.id
  description       = "Outbound (package installs, ECR, SSM)"
  cidr_ipv4         = "0.0.0.0/0"
  ip_protocol       = "-1"
}
