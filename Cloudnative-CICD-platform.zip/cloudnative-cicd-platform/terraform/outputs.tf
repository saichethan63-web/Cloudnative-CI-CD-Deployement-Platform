output "instance_id" {
  description = "EC2 instance ID (target of the SSM deploy command)."
  value       = aws_instance.app.id
}

output "public_ip" {
  description = "Elastic IP of the server."
  value       = aws_eip.app.public_ip
}

output "app_url" {
  description = "Application URL."
  value       = "http://${aws_eip.app.public_ip}"
}

output "grafana_url" {
  description = "Grafana URL (login: admin, password from SSM)."
  value       = "http://${aws_eip.app.public_ip}/grafana/"
}

output "ecr_repository_name" {
  value = aws_ecr_repository.app.name
}

output "ecr_repository_url" {
  value = aws_ecr_repository.app.repository_url
}

output "artifact_bucket" {
  value = aws_s3_bucket.artifacts.id
}

output "github_actions_role_arn" {
  description = "Store this in the GitHub secret AWS_ROLE_ARN."
  value       = aws_iam_role.github_actions.arn
}

output "grafana_password_parameter" {
  description = "Read the password with: aws ssm get-parameter --with-decryption --name <value>"
  value       = aws_ssm_parameter.grafana_admin_password.name
}

output "aws_region" {
  value = var.aws_region
}
