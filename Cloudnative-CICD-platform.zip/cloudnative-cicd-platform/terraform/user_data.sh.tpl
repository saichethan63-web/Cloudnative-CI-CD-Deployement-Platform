#!/bin/bash
# Bootstrap for Amazon Linux 2023. Installs Docker + Compose and the deploy helper.
# The application itself is delivered later by the CI/CD pipeline.
set -euxo pipefail
exec > >(tee /var/log/user-data.log) 2>&1

# Swap so the monitoring stack fits comfortably on small instances.
if [ ! -f /swapfile ]; then
  fallocate -l 2G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

dnf install -y docker jq

mkdir -p /etc/docker
cat > /etc/docker/daemon.json <<'JSON'
{
  "log-driver": "json-file",
  "log-opts": { "max-size": "10m", "max-file": "3" }
}
JSON
systemctl enable --now docker
usermod -aG docker ec2-user

mkdir -p /usr/local/lib/docker/cli-plugins
curl -fsSL "https://github.com/docker/compose/releases/download/v2.29.7/docker-compose-linux-x86_64" \
  -o /usr/local/lib/docker/cli-plugins/docker-compose
chmod +x /usr/local/lib/docker/cli-plugins/docker-compose

mkdir -p /etc/platform /opt/platform
cat > /etc/platform/config.env <<'CONFIG'
AWS_REGION=${aws_region}
APP_ENV=${environment}
SERVER_NAME=${server_name}
ARTIFACT_BUCKET=${artifact_bucket}
ECR_REGISTRY=${ecr_registry}
GRAFANA_PASSWORD_PARAM=${grafana_password_param}
CONFIG
chmod 644 /etc/platform/config.env

cat > /usr/local/bin/platform-deploy <<'PLATFORM_DEPLOY_SCRIPT'
${deploy_script}
PLATFORM_DEPLOY_SCRIPT
chmod 755 /usr/local/bin/platform-deploy

echo "Bootstrap complete" 
