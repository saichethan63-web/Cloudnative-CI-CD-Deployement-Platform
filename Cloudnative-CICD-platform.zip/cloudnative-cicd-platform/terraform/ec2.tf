data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["al2023-ami-2023.*-x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# Generated Grafana admin password, stored encrypted in SSM Parameter Store.
resource "random_password" "grafana" {
  length  = 24
  special = false
}

resource "aws_ssm_parameter" "grafana_admin_password" {
  name        = "/${var.project_name}/${var.environment}/grafana/admin_password"
  description = "Grafana admin password"
  type        = "SecureString"
  value       = random_password.grafana.result
}

resource "aws_instance" "app" {
  ami                         = data.aws_ami.al2023.id
  instance_type               = var.instance_type
  subnet_id                   = aws_subnet.public[0].id
  vpc_security_group_ids      = [aws_security_group.web.id]
  iam_instance_profile        = aws_iam_instance_profile.instance.name
  associate_public_ip_address = true
  monitoring                  = true

  user_data = templatefile("${path.module}/user_data.sh.tpl", {
    aws_region             = var.aws_region
    environment            = var.environment
    server_name            = var.server_name
    artifact_bucket        = aws_s3_bucket.artifacts.id
    ecr_registry           = split("/", aws_ecr_repository.app.repository_url)[0]
    grafana_password_param = aws_ssm_parameter.grafana_admin_password.name
    deploy_script          = file("${path.module}/scripts/platform-deploy.sh")
  })

  # IMDSv2 only: blocks SSRF-style credential theft.
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 2 # containers (e.g. cAdvisor) sit one hop away
  }

  root_block_device {
    volume_type           = "gp3"
    volume_size           = var.root_volume_size
    encrypted             = true
    delete_on_termination = true
  }

  tags = { Name = "${local.name}-app" }

  lifecycle {
    # A newer AMI or edited bootstrap script must not silently replace a running server.
    ignore_changes = [ami, user_data]
  }
}

# Stable public address that survives instance stop/start.
resource "aws_eip" "app" {
  domain   = "vpc"
  instance = aws_instance.app.id

  tags = { Name = "${local.name}-eip" }

  depends_on = [aws_internet_gateway.main]
}
