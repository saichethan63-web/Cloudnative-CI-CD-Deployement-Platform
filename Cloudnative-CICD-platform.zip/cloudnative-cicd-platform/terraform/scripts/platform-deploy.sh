#!/usr/bin/env bash
# Installed on the server at /usr/local/bin/platform-deploy by Terraform user_data.
# Invoked by GitHub Actions through AWS Systems Manager (no SSH):
#   platform-deploy <s3-key-of-bundle> <full-ecr-image-uri>
# Steps: fetch bundle -> render .env -> pull image -> start stack -> health check -> rollback on failure.
set -euo pipefail
export HOME="${HOME:-/root}"   # SSM runs without HOME; docker login needs it

# shellcheck disable=SC1091
source /etc/platform/config.env   # AWS_REGION ARTIFACT_BUCKET ECR_REGISTRY GRAFANA_PASSWORD_PARAM APP_ENV SERVER_NAME

BUNDLE_KEY="${1:?usage: platform-deploy <bundle-key> <image-uri>}"
APP_IMAGE="${2:?usage: platform-deploy <bundle-key> <image-uri>}"
DEPLOY_DIR=/opt/platform
LOCK=/var/lock/platform-deploy.lock

exec 9>"$LOCK"
flock -n 9 || { echo "Another deploy is running"; exit 1; }

mkdir -p "$DEPLOY_DIR"
cd "$DEPLOY_DIR"

echo "==> Fetching bundle s3://${ARTIFACT_BUCKET}/${BUNDLE_KEY}"
aws s3 cp "s3://${ARTIFACT_BUCKET}/${BUNDLE_KEY}" /tmp/bundle.tgz --region "$AWS_REGION" --only-show-errors
tar -xzf /tmp/bundle.tgz -C "$DEPLOY_DIR"
rm -f /tmp/bundle.tgz

PREVIOUS_IMAGE=""
if [ -f .env ]; then
  PREVIOUS_IMAGE=$(grep '^APP_IMAGE=' .env | cut -d= -f2- || true)
fi

GRAFANA_PASSWORD=$(aws ssm get-parameter --name "$GRAFANA_PASSWORD_PARAM" --with-decryption \
  --query Parameter.Value --output text --region "$AWS_REGION")
PUBLIC_HOST=$(curl -s -H "X-aws-ec2-metadata-token: $(curl -s -X PUT http://169.254.169.254/latest/api/token -H 'X-aws-ec2-metadata-token-ttl-seconds: 60')" \
  http://169.254.169.254/latest/meta-data/public-ipv4 || echo localhost)
[ "$SERVER_NAME" != "_" ] && PUBLIC_HOST="$SERVER_NAME"

write_env() {
  umask 077
  {
    echo "APP_IMAGE=$1"
    echo "APP_ENV=$APP_ENV"
    echo "HTTP_PORT=80"
    echo "SERVER_NAME=$SERVER_NAME"
    echo "PUBLIC_HOST=$PUBLIC_HOST"
    echo "GRAFANA_ADMIN_PASSWORD=$GRAFANA_PASSWORD"
  } > .env
}

health_check() {
  for _ in $(seq 1 30); do
    if curl -fsS http://127.0.0.1/api/health >/dev/null 2>&1; then return 0; fi
    sleep 3
  done
  return 1
}

echo "==> Logging in to ECR"
aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "$ECR_REGISTRY"

echo "==> Deploying $APP_IMAGE"
write_env "$APP_IMAGE"
docker compose pull app
docker compose up -d --no-build --remove-orphans

# Bind-mounted config changes do not recreate containers by themselves.
NEW_HASH=$(find nginx monitoring -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | cut -d' ' -f1)
if [ "$NEW_HASH" != "$(cat .config-hash 2>/dev/null || true)" ]; then
  echo "==> Config changed, recreating nginx, prometheus and grafana"
  docker compose up -d --no-build --force-recreate nginx prometheus grafana
  echo "$NEW_HASH" > .config-hash
fi

if health_check; then
  echo "==> Healthy: $APP_IMAGE"
  docker image prune -f >/dev/null
  docker compose ps
  exit 0
fi

echo "!! Health check failed"
docker compose logs --tail=50 app || true
if [ -n "$PREVIOUS_IMAGE" ] && [ "$PREVIOUS_IMAGE" != "$APP_IMAGE" ]; then
  echo "==> Rolling back to $PREVIOUS_IMAGE"
  write_env "$PREVIOUS_IMAGE"
  docker compose up -d --no-build --remove-orphans
  health_check && echo "==> Rollback succeeded" || echo "!! Rollback also unhealthy"
fi
exit 1
